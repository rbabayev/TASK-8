﻿
#include <iostream>
#include <string>
#include <cassert>
#include <map>
#include <queue>
using namespace std;


class Worker {
private:
    int _id;
    string _name;
    int _pageCount;
public:
    Worker(const string& name, int pageCount) {
        static int id = 0;
        _id = ++id;
        setName(name);
        _pageCount = pageCount;
    }

    void setName(const string& name) {
        int len = (_name).length();
        if (len >= 3)assert(!"Min character 3 !");
        _name = name;
    }

    int getId() const {
        return _id;
    }

    string getName() const {
        return _name;
    }

    void setPageCount(int pageCount) {
        _pageCount = pageCount;
    }

    int getPageCount() const {
        return _pageCount;
    }

    friend ostream& operator<<(ostream& print, const Worker& w1);
};

ostream& operator<<(ostream& print, const Worker& w1) 
{
    for (int i = 0; i < w1._pageCount; i++) 
    {
        print << i + 1 << ". " << w1._name << endl;
    }
    return print;
}

class Print
{
    string _name;
    queue<Worker> _arr;

public:
    Print(const string& name) {
        _name = name;
    }

    void PrintWorkers() 
    {
        cout <<"-- "<< _name <<" --"<< endl;
        int size = _arr.size();
        for (int i = 0; i < size; i++)
        {
            cout << _arr.front() << endl;
            _arr.pop();
        }
    }

    void Append(const Worker& W1) 
    {
        _arr.push(W1);
    }
 
};

int main() 
{

    Print p1("Fifa");

    Worker w1("Messi", 10);
    p1.Append(w1);
    Worker w2("Ronaldo", 7);
    p1.Append(w2);

    p1.PrintWorkers();

    return 0;
}
